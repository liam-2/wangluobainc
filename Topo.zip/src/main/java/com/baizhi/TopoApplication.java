package com.baizhi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//主启动类
@SpringBootApplication
public class TopoApplication {

    public static void main(String[] args) {
        SpringApplication.run(TopoApplication.class, args);
    }

}
