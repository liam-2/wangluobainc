package com.baizhi.controller;


import com.baizhi.entity.*;
import com.baizhi.service.TopoService;
import com.baizhi.vo.TopoResult;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.*;



@RestController
@CrossOrigin
@RequestMapping("topo")
public class TopoController {

    @Resource
    private TopoService topoService;


    //构造topo图
    @PostMapping("gettopo")
    public TopoResult saveOrUpdate(@RequestBody Ips ips) {

        String [] arr=ips.getGivenIps().split("\\s+");

        List<String> givenIpList= new ArrayList<String>(arr.length);

        Collections.addAll(givenIpList,arr);

        //获取可达ip列表
        List<String> givenIpList2=topoService.getIpList(givenIpList);

        System.out.println("givenIpList2"+givenIpList2);
        List<TracertResult> tracertList=topoService.getTracertList(givenIpList.get(0),givenIpList2);

        //givenIpList2.add(arr[0]);
        //System.out.println("tracertlist"+tracertList);

        List<IpResult> ipList=new ArrayList<IpResult>(givenIpList2.size()+1);

        for(int i=0;i<=givenIpList2.size();i++){
            if(i==0){
                ipList.add(new IpResult(i+1,arr[0]));
            }else{
                ipList.add(new IpResult(i+1,givenIpList2.get(i-1)));
            }

        }

        //Map<String,Integer> ipMap=ipList.stream().collect(Collectors.toMap(IpResult::getLabel,IpResult::getId));
        //构造map，用于根据ip获取id
        Map<String,Integer> ipMap=new HashMap<>();
        for(IpResult the:ipList){

            ipMap.put(the.getLabel(),the.getId());
        }
        //System.out.println("map"+ipMap);




        List<RelationResult> relationList=new ArrayList<>();
        for(int j=0;j<tracertList.size();j++){


            relationList.add(new RelationResult(String.valueOf(tracertList.get(j).id),
                    ipMap.get(tracertList.get(j).from),
                    ipMap.get(tracertList.get(j).to)));
            //tracertList.get(j).setFrom(ipMap.get(tracertList.get(j).getFrom()));
        }


      return new TopoResult(ipList,relationList);

    }

}
